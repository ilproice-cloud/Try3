# Realmforge

**Ascend. Forge. Conquer.**
An RPG progression mod for Minecraft 1.21.1 (Fabric): stats, ranks, races, and rarity-colored traits and perks.

## Build
Requires **Java 21**.

```
./gradlew build          # jar ends up in build/libs/
./gradlew runClient      # test in a dev client
./gradlew runServer      # test a dedicated server
```
Open the folder in IntelliJ IDEA (or VS Code) and import it as a Gradle project.
If a version in `gradle.properties` fails to resolve, pick the current 1.21.1 values from https://fabricmc.net/develop.

## Features
- **7 stats**: Vitality, Strength, Agility, Intelligence, Energy, Defense, Luck (values in `RealmforgeConfig.java`)
- **Levels 1-100** with 3 stat points per level, and **9 ranks** (Novice to Ascended)
- **One permanent trait** per player, rolled randomly the first time they join and never changed.
  6 rarities with colors: Common (white), Uncommon (green), Rare (blue), Epic (purple), Legendary (gold), Mythic (red)
- **XP sources**: killing hostile mobs, mining ores
- **Book screen**: the stats UI is the vanilla book screen itself. Turn pages, click [+] to spend points
- Data is saved per player (Fabric Data Attachment API), kept on death, synced to the client

## Controls
| Action | How |
|---|---|
| Open the book | **M**, the **RPG** button on the inventory / pause screen, or `/rpgmenu` |
| Turn pages | Page arrows, or Left / Right keys |
| Spend points | click **[+]** on page 1, or `/rpg spend <stat> [amount]` |
| Show stats as text | `/rpg` |
| Admin (OP 2) | `/rpg admin addxp <n>`, `/rpg admin reset` (keeps your trait) |

## Project layout
```
com.realmforge
  RealmforgeMod / RealmforgeConfig
  player/       RPGPlayerData, PlayerStats, StatType, Bonus*
  rarity/       Rarity, RarityManager
  registry/     TraitRegistry, Trait
  progression/  LevelManager, RankManager
  network/      RPGNetworkHandler, SyncPayload, SpendPointPayload
  event/        RPGEvents (join, respawn, regen, XP)
  command/      RPGCommands
  mixin/        LivingEntityMixin (damage, crit, dodge, defense, lifesteal)
  client/       RealmforgeClient, ClientRPGData (keybind, HUD, sync)
  screen/       RPGScreen
```

## Test checklist
1. Singleplayer: kill a zombie, mine coal, level up, spend points
2. Dedicated server + 2 clients: stats sync, can't spend more points than you have
3. Die and respawn: stats and traits are kept, max HP is re-applied
4. Log out and in: everything persists
5. PojavLauncher (Java 21 runtime): open the screen with the RPG button, tap the + buttons

## Ideas for later
Energy-cost skills, dungeons/realms, forged gear with rarity, party/guild features.
