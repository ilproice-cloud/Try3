package com.realmforge.screen;

import com.realmforge.RealmforgeConfig;
import com.realmforge.client.ClientRPGData;
import com.realmforge.network.SpendPointPayload;
import com.realmforge.player.Bonus;
import com.realmforge.player.StatType;
import com.realmforge.progression.RankManager;
import com.realmforge.rarity.Rarity;
import com.realmforge.registry.Trait;
import com.realmforge.registry.TraitRegistry;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.BookScreen;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.List;

/**
 * The stats screen IS the vanilla book screen. We only provide the page text.
 * Page 1: stats with clickable [+]   Page 2: overview   Page 3: your trait   Pages 4-5: stat guide
 */
public class RPGScreen extends BookScreen {
    private static final String SPEND_PREFIX = "rpg spend ";

    // Dark, parchment-friendly colors.
    private static final int GOLD_DARK = 0x8B6508;
    private static final int GRAY_DARK = 0x555555;
    private static final int GREEN_DARK = 0x006600;
    private static final int RED_DARK = 0xAA0000;
    private static final int[] STAT_COLORS = {0xAA0000, 0xC86400, 0x008800, 0x007788, 0x998800, 0x0000AA, 0xAA00AA};
    private static final int[] RANK_COLORS = {0x555555, 0x008800, 0x007788, 0x0000AA, 0xAA00AA, 0xC86400, 0xAA0000, 0xCC3399, 0x998800};

    public RPGScreen() {
        super(new BookScreen.Contents(List.of(
                statsPage(),
                overviewPage(),
                traitPage(),
                guidePage(0, 4),
                guidePage(4, StatType.values().length)
        )));
    }

    /**
     * Clicking [+] normally runs "/rpg spend <stat>" and closes the book. We catch it here instead,
     * send the spend to the server, and reopen the book on page 1 so you can keep clicking.
     * (No @Override on purpose: if the method name ever differs, vanilla's command click still works.)
     */
    public boolean handleTextClick(Style style) {
        if (style == null) return false;
        ClickEvent event = style.getClickEvent();
        if (event == null || event.getAction() != ClickEvent.Action.RUN_COMMAND) return false;

        String cmd = event.getValue();
        if (cmd.startsWith("/")) cmd = cmd.substring(1);
        if (!cmd.startsWith(SPEND_PREFIX)) return false;

        StatType stat = StatType.fromName(cmd.substring(SPEND_PREFIX.length()).trim());
        if (stat != null && ClientRPGData.points > 0) {
            // The server validates; it re-syncs if it disagrees.
            ClientPlayNetworking.send(new SpendPointPayload(stat.ordinal()));
            ClientRPGData.points--;
            ClientRPGData.stats[stat.ordinal()]++;
            MinecraftClient.getInstance().setScreen(new RPGScreen());
        }
        return true;
    }

    // ------------------------------------------------------------------ pages

    private static Text statsPage() {
        MutableText t = Text.empty();
        t.append(heading("Stats\n"));
        t.append(color("Points: " + ClientRPGData.points + "\n\n", 0x996600));

        StatType[] types = StatType.values();
        for (int i = 0; i < types.length; i++) {
            t.append(color(types[i].displayName + ": " + ClientRPGData.stats[i] + " ", STAT_COLORS[i]));
            if (ClientRPGData.points > 0) {
                t.append(plusLink(types[i]));
            }
            t.append(Text.literal("\n"));
        }
        return t;
    }

    private static Text overviewPage() {
        MinecraftClient mc = MinecraftClient.getInstance();
        int hp = 0, maxHp = 20;
        if (mc.player != null) {
            hp = (int) mc.player.getHealth();
            maxHp = (int) mc.player.getMaxHealth();
        }
        RankManager.Rank rank = RankManager.forLevel(ClientRPGData.level);
        String xp = ClientRPGData.level >= RealmforgeConfig.MAX_LEVEL
                ? "MAX" : ClientRPGData.xp + "/" + ClientRPGData.xpNeeded;

        MutableText t = Text.empty();
        t.append(heading("Realmforge\n\n"));
        t.append(Text.literal("Level " + ClientRPGData.level + "\n"));
        t.append(color(rank.displayName + "\n\n", RANK_COLORS[rank.ordinal()]));
        t.append(color("HP: " + hp + "/" + maxHp + "\n", RED_DARK));
        t.append(color("Energy: " + ClientRPGData.energy + "/" + ClientRPGData.maxEnergy + "\n", 0x0000AA));
        t.append(color("XP: " + xp + "\n\n", GREEN_DARK));
        t.append(color("Kill monsters and mine ores to level up.", GRAY_DARK));
        return t;
    }

    private static Text traitPage() {
        MutableText t = Text.empty();
        t.append(heading("Your Trait\n\n"));

        Trait trait = TraitRegistry.get(ClientRPGData.trait);
        if (trait == null) {
            t.append(color("Not rolled yet.", GRAY_DARK));
            return t;
        }
        int rc = rarityColor(trait.rarity());
        t.append(color("[" + trait.rarity().displayName + "]\n", rc));
        t.append(color(trait.name() + "\n\n", rc));
        for (Bonus b : trait.bonuses()) {
            t.append(color(b.describe() + "\n", b.value() < 0 ? RED_DARK : GREEN_DARK));
        }
        t.append(color("\nPermanent. It never changes.", GRAY_DARK));
        return t;
    }

    private static Text guidePage(int from, int to) {
        MutableText t = Text.empty();
        t.append(heading("Stat guide\n\n"));
        StatType[] types = StatType.values();
        for (int i = from; i < to; i++) {
            t.append(color(types[i].displayName + "\n", STAT_COLORS[i]));
            t.append(color(types[i].description + "\n", GRAY_DARK));
        }
        return t;
    }

    // ------------------------------------------------------------------ helpers

    private static MutableText heading(String s) {
        return Text.literal(s).formatted(Formatting.BOLD).styled(st -> st.withColor(GOLD_DARK));
    }

    private static MutableText color(String s, int rgb) {
        return Text.literal(s).styled(st -> st.withColor(rgb));
    }

    private static MutableText plusLink(StatType stat) {
        String command = "/" + SPEND_PREFIX + stat.name().toLowerCase();
        return Text.literal("[+]").styled(st -> st
                .withColor(GREEN_DARK)
                .withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, command))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                        Text.literal(stat.description))));
    }

    private static int rarityColor(Rarity rarity) {
        return switch (rarity) {
            case COMMON -> 0x555555;
            case UNCOMMON -> 0x008800;
            case RARE -> 0x0000AA;
            case EPIC -> 0xAA00AA;
            case LEGENDARY -> 0xC86400;
            case MYTHIC -> 0xAA0000;
        };
    }
}
