package com.realmforge.registry;

import com.realmforge.player.Bonus;
import com.realmforge.player.BonusType;
import com.realmforge.rarity.Rarity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class TraitRegistry {
    private TraitRegistry() {}

    private static final Map<String, Trait> TRAITS = new LinkedHashMap<>();

    static {
        // Common
        reg("thick_skin", "Thick Skin", Rarity.COMMON, b(BonusType.ARMOR, 1));
        reg("hardy", "Hardy", Rarity.COMMON, b(BonusType.MAX_HEALTH, 2));
        reg("nimble", "Nimble", Rarity.COMMON, b(BonusType.MOVE_SPEED, 2));
        reg("quick_learner", "Quick Learner", Rarity.COMMON, b(BonusType.XP_GAIN, 3));

        // Uncommon
        reg("brawler", "Brawler", Rarity.UNCOMMON, b(BonusType.DAMAGE, 5));
        reg("fleetfoot", "Fleetfoot", Rarity.UNCOMMON, b(BonusType.MOVE_SPEED, 4), b(BonusType.DODGE, 0.5));
        reg("iron_will", "Iron Will", Rarity.UNCOMMON, b(BonusType.DAMAGE_REDUCTION, 3));
        reg("lucky_charm", "Lucky Charm", Rarity.UNCOMMON, b(BonusType.CRIT_CHANCE, 2));

        // Rare
        reg("vampiric", "Vampiric", Rarity.RARE, b(BonusType.LIFESTEAL, 5));
        reg("stalwart", "Stalwart", Rarity.RARE, b(BonusType.ARMOR, 2), b(BonusType.MAX_HEALTH, 4));
        reg("deep_reserves", "Deep Reserves", Rarity.RARE, b(BonusType.MAX_ENERGY, 20), b(BonusType.XP_GAIN, 5));
        reg("berserker", "Berserker", Rarity.RARE, b(BonusType.DAMAGE, 10));

        // Epic (strong, some with a drawback)
        reg("glass_cannon", "Glass Cannon", Rarity.EPIC, b(BonusType.DAMAGE, 30), b(BonusType.MAX_HEALTH, -4));
        reg("shadow_step", "Shadow Step", Rarity.EPIC, b(BonusType.DODGE, 4), b(BonusType.MOVE_SPEED, 6));
        reg("juggernaut", "Juggernaut", Rarity.EPIC, b(BonusType.ARMOR, 3), b(BonusType.DAMAGE_REDUCTION, 6), b(BonusType.MOVE_SPEED, -5));
        reg("sharpshooter", "Sharpshooter", Rarity.EPIC, b(BonusType.CRIT_CHANCE, 8), b(BonusType.DAMAGE, 8));

        // Legendary
        reg("blood_pact", "Blood Pact", Rarity.LEGENDARY, b(BonusType.LIFESTEAL, 10), b(BonusType.DAMAGE, 15), b(BonusType.MAX_HEALTH, -6));
        reg("titans_heart", "Titan's Heart", Rarity.LEGENDARY, b(BonusType.MAX_HEALTH, 12), b(BonusType.DAMAGE_REDUCTION, 5));
        reg("ghostwalker", "Ghostwalker", Rarity.LEGENDARY, b(BonusType.DODGE, 8), b(BonusType.MOVE_SPEED, 10));

        // Mythic
        reg("phoenix_soul", "Phoenix Soul", Rarity.MYTHIC, b(BonusType.MAX_HEALTH, 20), b(BonusType.LIFESTEAL, 8), b(BonusType.DAMAGE_REDUCTION, 8));
        reg("ascendant", "Ascendant", Rarity.MYTHIC, b(BonusType.DAMAGE, 20), b(BonusType.XP_GAIN, 25), b(BonusType.CRIT_CHANCE, 10), b(BonusType.MAX_ENERGY, 50));
    }

    private static Bonus b(BonusType type, double value) {
        return new Bonus(type, value);
    }

    private static void reg(String id, String name, Rarity rarity, Bonus... bonuses) {
        TRAITS.put(id, new Trait(id, name, rarity, List.of(bonuses)));
    }

    public static void init() {}

    public static Trait get(String id) {
        return TRAITS.get(id);
    }

    public static Collection<Trait> all() {
        return TRAITS.values();
    }

    public static List<Trait> byRarity(Rarity rarity) {
        List<Trait> list = new ArrayList<>();
        for (Trait t : TRAITS.values()) {
            if (t.rarity() == rarity) list.add(t);
        }
        return list;
    }
}
