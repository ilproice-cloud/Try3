package com.realmforge.player;

public enum BonusType {
    MAX_HEALTH("Max HP", false),
    ARMOR("Armor", false),
    MOVE_SPEED("Move Speed", true),
    DAMAGE("Damage", true),
    DAMAGE_REDUCTION("Damage Reduction", true),
    LIFESTEAL("Lifesteal", true),
    CRIT_CHANCE("Crit Chance", true),
    DODGE("Dodge", true),
    MAX_ENERGY("Max Energy", false),
    XP_GAIN("XP Gain", true);

    public final String label;
    public final boolean percent;

    BonusType(String label, boolean percent) {
        this.label = label;
        this.percent = percent;
    }
}
