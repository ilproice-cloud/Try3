package com.realmforge.player;

public record Bonus(BonusType type, double value) {
    public String describe() {
        String sign = value >= 0 ? "+" : "";
        String num = value == Math.rint(value) ? String.valueOf((int) value) : String.format("%.1f", value);
        return sign + num + (type.percent ? "%" : "") + " " + type.label;
    }
}
