package com.realmforge.network;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> Server: "spend one point on this stat". The server validates everything. */
public record SpendPointPayload(int stat) implements CustomPayload {
    public static final Id<SpendPointPayload> ID = new Id<>(Identifier.of("realmforge", "spend_point"));

    public static final PacketCodec<RegistryByteBuf, SpendPointPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, SpendPointPayload::stat, SpendPointPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
