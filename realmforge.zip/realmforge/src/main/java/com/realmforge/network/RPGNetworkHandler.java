package com.realmforge.network;

import com.realmforge.player.PlayerStats;
import com.realmforge.player.RPGPlayerData;
import com.realmforge.player.StatType;
import com.realmforge.progression.LevelManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

public final class RPGNetworkHandler {
    private RPGNetworkHandler() {}

    /** Registers payload types (both sides need this) and the server receiver. */
    public static void registerServer() {
        PayloadTypeRegistry.playC2S().register(SpendPointPayload.ID, SpendPointPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncPayload.ID, SyncPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SpendPointPayload.ID, (payload, context) -> {
            StatType[] types = StatType.values();
            int index = payload.stat();
            if (index < 0 || index >= types.length) return;
            ServerPlayerEntity player = context.player();
            // Never trust the client: LevelManager checks the real point count.
            if (!LevelManager.spend(player, types[index], 1)) {
                sync(player); // correct the client's optimistic update
            }
        });
    }

    public static void sync(ServerPlayerEntity player) {
        RPGPlayerData d = RPGPlayerData.get(player);
        ServerPlayNetworking.send(player, new SyncPayload(
                d.level, d.xp, LevelManager.xpNeeded(d.level), d.points,
                d.energy, PlayerStats.maxEnergy(d),
                d.statList(), d.trait));
    }
}
