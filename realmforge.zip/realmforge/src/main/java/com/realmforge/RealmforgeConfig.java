package com.realmforge;

/** Central tuning values. Change these to rebalance the mod. */
public final class RealmforgeConfig {
    private RealmforgeConfig() {}

    // Progression
    public static final int MAX_LEVEL = 100;
    public static final int START_POINTS = 5;
    public static final int POINTS_PER_LEVEL = 3;

    // Resources
    public static final int BASE_ENERGY = 100;
    public static final int BASE_ENERGY_REGEN = 2; // per 2 seconds

    // Per-point stat values
    public static final double HP_PER_VITALITY = 5.0;
    public static final double PHYSICAL_DMG_PCT_PER_STRENGTH = 2.0;
    public static final double SPEED_PCT_PER_AGILITY = 0.5;
    public static final double DODGE_PCT_PER_AGILITY = 0.05;
    public static final double MAGIC_DMG_PCT_PER_INTELLIGENCE = 2.0;
    public static final int ENERGY_PER_POINT = 2;
    public static final double REDUCTION_PCT_PER_DEFENSE = 0.2;
    public static final double CRIT_PCT_PER_LUCK = 0.25;
    public static final double LUCK_ATTRIBUTE_PER_LUCK = 0.05;

    // Caps
    public static final double DEFENSE_CAP_PCT = 75.0;
    public static final double DODGE_CAP_PCT = 60.0;
    public static final float CRIT_MULTIPLIER = 1.5f;
}
