package com.realmforge.client;

import com.realmforge.network.SyncPayload;
import com.realmforge.progression.RankManager;
import com.realmforge.screen.RPGScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class RealmforgeClient implements ClientModInitializer {
    private static KeyBinding openStats;

    @Override
    public void onInitializeClient() {
        // Server -> client data sync
        ClientPlayNetworking.registerGlobalReceiver(SyncPayload.ID,
                (payload, context) -> ClientRPGData.apply(payload));

        // M key
        openStats = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.realmforge.open_stats",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                "category.realmforge"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openStats.wasPressed()) {
                if (client.player != null && client.currentScreen == null) {
                    client.setScreen(new RPGScreen());
                }
            }
        });

        // Touch-friendly fallbacks for PojavLauncher (no M key):
        // 1) an "RPG" button on the inventory and pause screens
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof InventoryScreen || screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("RPG"),
                                b -> client.setScreen(new RPGScreen()))
                        .dimensions(4, 4, 44, 20)
                        .build());
            }
        });

        // 2) /rpgmenu (client command)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("rpgmenu").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    // Delay a tick so the closing chat screen doesn't replace ours.
                    mc.send(() -> mc.setScreen(new RPGScreen()));
                    return 1;
                })));

        // Small HUD: level, rank, energy and XP bars
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;
            TextRenderer tr = mc.textRenderer;
            RankManager.Rank rank = RankManager.forLevel(ClientRPGData.level);

            ctx.drawTextWithShadow(tr,
                    Text.literal("Lv " + ClientRPGData.level + " " + rank.displayName).formatted(rank.color),
                    6, 6, 0xFFFFFF);

            int w = 80;
            float energyPct = Math.min(1f, (float) ClientRPGData.energy / Math.max(1, ClientRPGData.maxEnergy));
            ctx.fill(6, 18, 6 + w, 24, 0xAA000000);
            ctx.fill(6, 18, 6 + (int) (w * energyPct), 24, 0xFF2288DD);

            float xpPct = Math.min(1f, (float) ClientRPGData.xp / Math.max(1, ClientRPGData.xpNeeded));
            ctx.fill(6, 26, 6 + w, 29, 0xAA000000);
            ctx.fill(6, 26, 6 + (int) (w * xpPct), 29, 0xFF44BB44);
        });
    }
}
