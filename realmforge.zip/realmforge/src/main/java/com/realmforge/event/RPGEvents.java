package com.realmforge.event;

import com.realmforge.RealmforgeConfig;
import com.realmforge.network.RPGNetworkHandler;
import com.realmforge.player.PlayerStats;
import com.realmforge.player.RPGPlayerData;
import com.realmforge.player.StatType;
import com.realmforge.progression.LevelManager;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.mob.Monster;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.LinkedHashMap;
import java.util.Map;

public final class RPGEvents {
    private RPGEvents() {}

    private static final Map<TagKey<Block>, Integer> ORE_XP = new LinkedHashMap<>();

    static {
        ORE_XP.put(BlockTags.COAL_ORES, 2);
        ORE_XP.put(BlockTags.COPPER_ORES, 2);
        ORE_XP.put(BlockTags.REDSTONE_ORES, 3);
        ORE_XP.put(BlockTags.IRON_ORES, 4);
        ORE_XP.put(BlockTags.LAPIS_ORES, 4);
        ORE_XP.put(BlockTags.GOLD_ORES, 5);
        ORE_XP.put(BlockTags.DIAMOND_ORES, 12);
        ORE_XP.put(BlockTags.EMERALD_ORES, 12);
    }

    public static void register() {
        // Join: apply attribute bonuses and send the first sync.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.player;
            LevelManager.ensureTrait(player); // first join: roll the one permanent trait
            PlayerStats.applyAttributes(player);
            RPGNetworkHandler.sync(player);
        });

        // Respawn: attachment is copied on death; re-apply attributes on the new entity.
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            PlayerStats.applyAttributes(newPlayer);
            if (!alive) newPlayer.setHealth(newPlayer.getMaxHealth());
            RPGNetworkHandler.sync(newPlayer);
        });

        // Energy regen every 2 seconds.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 40 != 0) return;
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                RPGPlayerData d = RPGPlayerData.get(player);
                int max = PlayerStats.maxEnergy(d);
                if (d.energy < max) {
                    d.energy = Math.min(max, d.energy
                            + RealmforgeConfig.BASE_ENERGY_REGEN + d.getStat(StatType.ENERGY) / 10);
                    d.save(player);
                    RPGNetworkHandler.sync(player);
                }
            }
        });

        // XP from killing hostile mobs.
        ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((world, entity, killed) -> {
            if (entity instanceof ServerPlayerEntity player && killed instanceof Monster) {
                int xp = Math.max(2, (int) (killed.getMaxHealth() / 2));
                LevelManager.addXp(player, xp);
            }
        });

        // XP from mining ores.
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (player instanceof ServerPlayerEntity serverPlayer) {
                int xp = oreXp(state);
                if (xp > 0) LevelManager.addXp(serverPlayer, xp);
            }
        });
    }

    private static int oreXp(BlockState state) {
        for (Map.Entry<TagKey<Block>, Integer> e : ORE_XP.entrySet()) {
            if (state.isIn(e.getKey())) return e.getValue();
        }
        return 0;
    }
}
