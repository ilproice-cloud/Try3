package com.realmforge.rarity;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public enum Rarity {
    COMMON("Common", Formatting.WHITE, 55.0),
    UNCOMMON("Uncommon", Formatting.GREEN, 25.0),
    RARE("Rare", Formatting.BLUE, 12.0),
    EPIC("Epic", Formatting.DARK_PURPLE, 6.0),
    LEGENDARY("Legendary", Formatting.GOLD, 1.8),
    MYTHIC("Mythic", Formatting.RED, 0.2);

    public final String displayName;
    public final Formatting color;
    public final double weight;

    Rarity(String displayName, Formatting color, double weight) {
        this.displayName = displayName;
        this.color = color;
        this.weight = weight;
    }

    public Text label() {
        return Text.literal(displayName).formatted(color);
    }
}
